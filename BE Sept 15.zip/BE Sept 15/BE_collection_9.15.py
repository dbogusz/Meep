import meep as mp
import matplotlib.pyplot as plt
import numpy as np
import math as math
import cmath
from matplotlib import ticker, cm
from scipy.integrate import simps

from meep.materials import Au,SiO2

GaAs=mp.Medium(index=2.67)
#2.67
#3.885
#SiO2=mp.Medium(index=1.4500)
#Au=mp.Medium(index=0.3970)

#Note: there are an extra parameter setting of 'figure', this is for investigation of how parameters affect the device's performance. With 'figure=False', there won't be figures output.  


class Bullseye:
    
    def __init__(self,width,rthickness,cr,num,tdev,tsio2,tau):
        self.width=width #width of etches
        self.rthickness=rthickness #thickness of the grating in r direction
        self.cr=cr #radius of centre disk
        self.num=num #number of etches
        self.tdev=tdev #thickness of GaAs Layer (z-dir)
        self.tsio2=tsio2 #thickness of SiO2 Layer (z-dir)
        self.tau=tau #thickness of Au Layer (z-dir)
        
        self._cellsize=None
        self._geometry=None
        self._sources=None
        self._dimensions=mp.CYLINDRICAL
        self._sim=None
        
    def define_cellsize(self,pad,dpml):
        
        self.pad=pad #thickness of air padding 
        #self.dpml_r=dpml_r #thickness of the absorbing palyer in r direction
        self.dpml=dpml 
        
        self.sr = self.num*(self.width+self.rthickness)+self.cr+self.dpml+self.pad #size of cell in r direction
        self.sz = 2*self.dpml+2*self.pad+self.tdev+self.tsio2+self.tau #size of cell in z direction
        
        self._cellsize=mp.Vector3(self.sr,0,self.sz)
    
    def define_geometry(self):
            
        self._geometry=[]
            
        current_layer_position= -0.5*self.sz+self.pad+self.dpml #count from bottom
            
        device_radius=self.sr-self.pad-self.dpml
            
        current_layer_thickness=self.tau                             
        Aufilm=mp.Block(
           center=mp.Vector3(0,0,current_layer_position+0.5*current_layer_thickness),
                size=mp.Vector3(device_radius,0,current_layer_thickness),
                material=Au)
            
        current_layer_position += current_layer_thickness
        current_layer_thickness = self.tsio2
             
            
        basis=mp.Block(            center=mp.Vector3(0,0,current_layer_position+0.5*current_layer_thickness),
                       size=mp.Vector3(device_radius,0,current_layer_thickness),
                       material=SiO2)
            
        current_layer_position += current_layer_thickness
        current_layer_thickness = self.tdev
            
        indisk=mp.Block(
                center=mp.Vector3(0,0,current_layer_position+0.5*current_layer_thickness),
                       size=mp.Vector3(2*self.cr,0,current_layer_thickness),
                       material=GaAs)   #define the central disk
        
        self._geometry.append(Aufilm)
        self._geometry.append(basis)
        self._geometry.append(indisk)
            #construct the gratings
        for i in range(1,self.num+1,1):
            self._geometry.append(
                mp.Block(center=mp.Vector3(self.cr+i*self.width+(i-1)*self.rthickness+0.5*self.rthickness,0,current_layer_position+0.5*current_layer_thickness),                           size=mp.Vector3(self.rthickness,0,current_layer_thickness),
                                    material=GaAs))
                
        self.source_position= current_layer_position + 0.5* current_layer_thickness
            
    
    def define_sources(self,wvl_min=1.2,wvl_max=1.6):
        
            
        self.wvl_min=wvl_min
        self.wvl_max=wvl_max
                #define the location shift of sources in z direction, +:+z,-:-z
        
        self.wvl_cen=0.5*(self.wvl_min+self.wvl_max)
        self.fmin=1/self.wvl_max
        self.fmax=1/self.wvl_min
        self.fcen=0.5*(self.fmin+self.fmax)
        self.df=self.fmax-self.fmin
        
        
        self._sources=[mp.Source(mp.GaussianSource(self.fcen,fwidth=self.df),
                     component=mp.Er,
                     center=mp.Vector3(0,0,self.source_position),
                     amplitude=1)]
        
    def define_simulation(self,resolution=100,m=+1,courant=0.5,normalrun=False):
            
        self.resolution=resolution
        self.m=m
        self.courant=courant
        self.normalrun=normalrun #if normalrun is true, geometry=[]
        
        self.dev_top_position=0.5*self.sz-self.pad-self.dpml
        self.dev_bot_position=-0.5*self.sz+self.pad+self.dpml
        self.dev_side_position=self.sr-self.pad-self.dpml
            
        if self.normalrun is False:
            self._sim=mp.Simulation(cell_size=self._cellsize,
                    geometry=self._geometry,
                    boundary_layers=[mp.PML(self.dpml,pml_profile=lambda u: u * u * u)],
                    resolution=self.resolution,
                    sources=self._sources,
                    dimensions=self._dimensions,
                    m=self.m,
                    progress_interval=50,
                    Courant=self.courant,
                    force_complex_fields=True)
        else:
            self._sim=mp.Simulation(cell_size=self._cellsize,
                    geometry=[],
                    boundary_layers=[mp.PML(self.dpml,pml_profile=lambda u: u * u * u)],
                    resolution=self.resolution,
                    sources=self._sources,
                    dimensions=self._dimensions,
                    m=self.m,
                    progress_interval=50,
                    Courant=self.courant,
                    force_complex_fields=True)

    def end_simulation(self):
        
        self._sim.reset_meep()
        self._cellsize = None
        self._geometry = None
        self._sources = None
        self._sim = None
    
    def define_box_monitors(self, wvl_flux_min=1.2, wvl_flux_max=1.6, box_dis=0.5, nfreq_box=200):
            
        self.wvl_flux_min=wvl_flux_min
        self.wvl_flux_max=wvl_flux_max
        self.box_dis=box_dis
        self.nfreq_box =nfreq_box
                       
        self.fmin_flux=1/self.wvl_flux_max
        self.fmax_flux=1/self.wvl_flux_min
        self.fcen_flux=0.5*(self.fmin_flux+self.fmax_flux)
        self.df_flux=self.fmax_flux-self.fmin_flux
            
            #bottom surface
        self.box_z1 = self._sim.add_flux(self.fcen_flux, self.df_flux, self.nfreq_box, 
                    mp.FluxRegion(center=mp.Vector3(0,0,self.source_position-self.box_dis),
                    size=mp.Vector3(2*self.box_dis),direction=mp.Z,weight=-1))
            #upper surface
        self.box_z2 = self._sim.add_flux(self.fcen_flux, self.df_flux, self.nfreq_box,
                    mp.FluxRegion(center=mp.Vector3(0,0,self.source_position+self.box_dis),
                    size=mp.Vector3(2*self.box_dis),direction=mp.Z,weight=+1))
            #side surface
        self.box_r = self._sim.add_flux(self.fcen_flux, self.df_flux, self.nfreq_box, 
                    mp.FluxRegion(center=mp.Vector3(self.box_dis,0,self.source_position),
                    size=mp.Vector3(z=2*self.box_dis),direction=mp.R,weight=+1))

            
    def define_near_field_box(self,wvl_fcen_near=1,near_box_dis=1):
        
        if self._sim is not None:
            self.nfreq_near=1
            self.near_box_dis=near_box_dis #distance from the whole structure
        
            self.fcen_near=1/wvl_fcen_near
            self.df_near=0
            
            
    
            
            #a box
            self.near_field_z2=self._sim.add_near2far(self.fcen_near,self.df_near,self.nfreq_near,
                            mp.Near2FarRegion(mp.Vector3(0,0,self.dev_bot_position-self.near_box_dis),
                                              size=mp.Vector3(2*(self.dev_side_position+self.near_box_dis)),
                                              direction=mp.Z,weight=-1),
                            mp.Near2FarRegion(mp.Vector3(0,0,self.dev_top_position+self.near_box_dis),
                                              size=mp.Vector3(2*(self.dev_side_position+self.near_box_dis)),
                                              direction=mp.Z,weight=+1),
                            mp.Near2FarRegion(mp.Vector3(self.dev_side_position+self.near_box_dis,0,0),
                                              size=mp.Vector3(z=self.dev_top_position-self.dev_bot_position+2*self.near_box_dis),
                                              direction=mp.R,weight=+1))
            
        else:
            raise Exception('Need defining simulation first')
        
    def plot_epslion(self):
               
        self._sim.init_fields()
        #z*r source plane
        self.eps_data = self._sim.get_array(center=mp.Vector3(0,0,0), 
                                        size=mp.Vector3(2*self.sr,0,self.sz),
                                            component=mp.Dielectric) 
            
        plt.imshow(self.eps_data, interpolation='none', origin='lower', cmap="Greys")
        plt.ylabel('z')
        plt.xlabel('r $\phi$=0')
        plt.title('The structure displayed in Z-R plane')
            
        # the Horizontal plane of source
        self.eps_data_rp =self._sim.get_array(center=mp.Vector3(self.sr/2,0,self.source_position), 
                                        size=mp.Vector3(self.sr,0,0),
                                            component=mp.Dielectric)
            
            
        thetas = np.radians(np.arange(0, 360, 0.1))
        zeniths = np.arange(0, len(self.eps_data_rp),1)

        values=[]
        for i in range(len(thetas)):
            values.append(self.eps_data_rp)
    
        values=np.array(values)

        r, theta = np.meshgrid(zeniths, thetas)
        fig, ax = plt.subplots(subplot_kw=dict(projection='polar'),dpi=200)
        ax.contourf(theta, r, values,cmap=cm.Greys_r)
        plt.title('Overview of the structure')
        plt.show()
            
    def get_Er_field(self,time_after_sources=150):
        
        if self._sim is not None:
            
            
            self.time_after_sources=time_after_sources
            self._sim.run(until_after_sources=self.time_after_sources)
        else:
            raise Exception('Need defining simulation first')
            
           
            
    def plot_Er_field(self,figure=True):
        #get Er z*r slice
        if figure is True:
            Er_data=self._sim.get_array(center=mp.Vector3(0,0,0),
                                size=mp.Vector3(2*(self.sr-self.pad),0,self.sz),
                                component=mp.Er,
                                cmplx=False)
            
            Er_data=np.array(Er_data)
        
            Ir_data=np.multiply(Er_data,Er_data)
    
            plt.figure(dpi=150)
            plt.imshow(Er_data, 
            interpolation='none', 
             origin='lower', 
             cmap = plt.cm.jet)
            plt.colorbar()
            plt.title('E-field of Z-R plane')
            plt.show()
            
            #get Horizontal |E|^2 slice of source plane
            
            Er_data_rp=self._sim.get_array(
                    center=mp.Vector3(self.sr/2,0,self.source_position),
                                size=mp.Vector3(self.sr,0,0),
                                component=mp.Er,
                                cmplx=False)
            
            Er_data_rp=np.array(Er_data_rp)
        
            
            thetas = np.radians(np.arange(0, 360, 0.1))
            zeniths = np.arange(0, len(Er_data_rp),1)
            Ir_data_rp_p=np.multiply(Er_data_rp,Er_data_rp) # calculate |Er|^2
            
            values=[]
            for i in range(len(thetas)):
                values.append(Ir_data_rp_p)
            values=np.array(values)

            r, theta = np.meshgrid(zeniths, thetas)
            fig, ax = plt.subplots(subplot_kw=dict(projection='polar'),dpi=150)
            cs=ax.pcolormesh(theta, r, values,cmap=cm.RdYlBu_r,shading='auto')
            fig.colorbar(cs)
            plt.title('|Er|^2 at source plane-whole source')
            plt.show()
            
        
            
    #for extract field data of each mode        
    def define_mode_field(self,mode_wvl=[]):
        
        if self._sim is not None:
            
            self.mode_fcen=[]
            for i in range(len(mode_wvl)):
                self.mode_fcen.append(1/mode_wvl[i])
            #get data at device upper surface and cover all device    
            self.dft_obj=self._sim.add_dft_fields([mp.Er],self.mode_fcen,
                                                    where=mp.Volume(center=mp.Vector3((self.cr)/2,0,self.dev_top_position),
                                                    size=mp.Vector3(self.cr,0,0))) 
            self.mode_fcen_v=[]
            for i in range(len(mode_wvl)):
                self.mode_fcen_v.append(1/mode_wvl[i])
            #get data at device upper surface and cover all device    
            self.dft_obj_v=self._sim.add_dft_fields([mp.Er],self.mode_fcen_v,
                                                    where=mp.Volume(center=mp.Vector3(0,0,0),
                                                    size=mp.Vector3(self.sr-self.dpml-self.pad,0,self.sz-2*(self.dpml-self.pad))))
        
    def get_q_values(self,time_after_sources=150):
            
        self.time_after_sources=time_after_sources
        #get q values at sources
        harminv_instance = mp.Harminv(mp.Er, mp.Vector3(0,0,self.source_position),self.fcen,self.df)
        self._sim.run(
                    mp.after_sources(harminv_instance),until_after_sources=self.time_after_sources)
        
        self.q_results=[]
    
        for mode in harminv_instance.modes:
                
            self.q_results.append([1000/mode.freq,mode.decay,mode.Q,abs(mode.amp)]) 
        
        self.q_results = np.array(self.q_results)
        
        #this part is aim to find the fundamental mode based on their amplitude.
        max_q_amp = max(self.q_results[:, 3])
        max_q_index = np.where(self.q_results[:, 3] == max_q_amp)
        max_q_wvl= self.q_results[max_q_index,0]
        max_q=self.q_results[max_q_index,2]
        
            
        self.print_q_values()
        
        return max_q_wvl,max_q
        
    def print_q_values(self,figure=True):
        
        if figure is True:
            print("-")
            for i in range(len(self.q_results)):
                print("Wavelength in nm:", self.q_results[i,0])
                print("Decay:", self.q_results[i,1])
                print("Q factor:", self.q_results[i,2])
                print("Amplitude:", self.q_results[i,3])
                print("-")
    
            
    def get_ldos(self,time_after_sources=150,nfreq_ldos=200):
        
            
        self.time_after_sources=time_after_sources
        self.nfreq_ldos=nfreq_ldos
        
        ldos_instance = mp.Ldos(self.fcen,self.df,self.nfreq_ldos)
        self._sim.run(             mp.dft_ldos(ldos=ldos_instance),until_after_sources=self.time_after_sources)
            
        
        self.ldos_results = np.transpose(np.array([mp.get_ldos_freqs(ldos_instance),self._sim.ldos_data]))
    
 
    def plot_ldos(self,figure=True):
        
        maximum = max(self.ldos_results[:, 1])
        index = np.where(self.ldos_results[:, 1] == maximum)
        mode_wvl=1000/self.ldos_results[index, 0]
                
        if figure is True:
            print('Peak at',mode_wvl,'nm')
    
            plt.figure(dpi=150)
            plt.plot(1 / self.ldos_results[:, 0], self.ldos_results[:, 1], 'b-')
            plt.plot(1 / self.ldos_results[index, 0], self.ldos_results[index, 1],'r.')
            plt.axvline(x=mode_wvl/1000,color='b',linestyle='--') #mark where ldos is maximum
                    
            plt.xlabel("Wavelength $\lambda$ ($\mu m$)")
            plt.ylabel("LDOS")
            plt.title("LDOS of some bullseye structure")
            plt.show()
                
        return mode_wvl,maximum  # structure's fundamental mode wvl
    
    def get_mode_field(self,until_after_sources=150):
        if self._sim is not None:
            
            self.until_after_sources=until_after_sources
        
            self._sim.run(until_after_sources=self.until_after_sources)
            
            self.mode_field_data=[]
            
            for i in range(len(self.mode_fcen)):
                self.mode_field_data.append(
                    self._sim.get_dft_array(self.dft_obj,mp.Er,i))
            
            self.mode_field_data=np.array(self.mode_field_data)
            
            self.mode_field_data_v=[]
            
            for i in range(len(self.mode_fcen)):
                self.mode_field_data_v.append(
                    self._sim.get_dft_array(self.dft_obj_v,mp.Er,i))
            
            self.mode_field_data_v=np.array(self.mode_field_data_v)
            
            
            
    def plot_mode_field(self):
        
        for n in range(len(self.mode_field_data)):
            
            thetas = np.radians(np.arange(0, 360, 0.1))
            zeniths = np.arange(0, len(self.mode_field_data[n]),1)
            mode_I=np.real(np.multiply(np.conj(
                self.mode_field_data[n]),self.mode_field_data[n]))
                
            values=[]
            for i in range(len(thetas)):
                values.append(mode_I)
    
            values=np.array(values)

            r, theta = np.meshgrid(zeniths, thetas)
            fig, ax = plt.subplots(subplot_kw=dict(projection='polar'),dpi=150)
            cs=ax.pcolormesh(theta, r, values,cmap=cm.RdYlBu_r,shading='auto')
            fig.colorbar(cs)
            plt.title('|Er|^2 distribution of central disk for mode %1.4f um at device surface' %(1/self.mode_fcen[n]))
            plt.show()
            
            mode_I_v=np.real(np.multiply(np.conj(
                self.mode_field_data_v[n]),self.mode_field_data_v[n]))
            plt.figure(dpi=150)
            plt.imshow(mode_I_v.real, 
            interpolation='none', 
             origin='lower', 
             cmap = plt.cm.jet)
            plt.colorbar()
            plt.title('|Er|^2 distribution of Z-R plane of mode %1.4f um' %(1/self.mode_fcen[n]))
            plt.show()
            

    def get_power(self,time_after_sources=150):  
    
                                            
        self.time_after_sources=time_after_sources

        self._sim.run(until_after_sources=self.time_after_sources)
     
            
    def plot_power(self,figure=True):
        
        
        flux_freqs = np.array(mp.get_flux_freqs(self.box_z2))
        flux_up = np.array(mp.get_fluxes(self.box_z2))
        flux_bot = np.array(mp.get_fluxes(self.box_z1))
        flux_side = np.array(mp.get_fluxes(self.box_r))
        flux_total= flux_bot+flux_up+flux_side
        
  
        max_uppower = max(flux_up)
    
        max_upindex = np.where(flux_up == max_uppower)
        maxwvl=1/flux_freqs[max_upindex] #find the wavelength of maximum
  
        sum_upratio = sum(flux_up)/sum(flux_total) #the ratio of total upward power
        max_upratio = max(flux_up)/flux_total[max_upindex] #at the most productive wavelength, thr ratio of upward power
            

        flux_wvl=1/flux_freqs
        
        if figure is True:
            print('Max up-power ratio at %1.4f' %(maxwvl))
        
    
            plt.figure(dpi=150)
            plt.axvline(x=maxwvl,color='b',linestyle='--') #mark where most productive wavelength
            plt.plot(flux_wvl, flux_total, 'r-', label='Total emission')
            plt.plot(flux_wvl, flux_bot, 'g-', label='Bottom emission')
            plt.plot(flux_wvl, flux_side, 'y-', label='Side emission')
            plt.plot(flux_wvl, flux_up, 'b-',label='Upward emission')
            plt.legend(loc='upper right')
            plt.xlabel('Wavelength (µm)')
            plt.ylabel('Poynting flux')
            
        return sum_upratio,max_upratio,maxwvl
        
            
    def run_all(self,time_after_sources=150, nfreq_ldos=200,figure=True):
        
            
        self.time_after_sources = time_after_sources
        self.nfreq_ldos = nfreq_ldos
        self.figure=figure
            
        self.harminv_instance = mp.Harminv(mp.Er, mp.Vector3(0,0,self.source_position),self.fcen,self.df)
            
        self.ldos_instance = mp.Ldos(self.fcen,self.df,self.nfreq_ldos)
            
        self._sim.run(mp.after_sources(self.harminv_instance), mp.dft_ldos(ldos=self.ldos_instance),until_after_sources=self.time_after_sources)
            
        self.ldos_results = np.transpose(np.array([mp.get_ldos_freqs(self.ldos_instance),self._sim.ldos_data]))
            
        self.q_results=[]
   
        for mode in self.harminv_instance.modes:
            self.q_results.append(
                    [1000/mode.freq,mode.decay,mode.Q,abs(mode.amp)]) 
        
        self.q_results = np.array(self.q_results)
        
        max_q_amp = max(self.q_results[:, 3])
        max_q_index = np.where(self.q_results[:, 3] == max_q_amp)
        max_q_wvl= self.q_results[max_q_index,0]
        max_q=self.q_results[max_q_index,2]
        
        q_data=[max_q_wvl,max_q]
            
        self.print_q_values(figure=self.figure)
        flux_data=self.plot_power(figure=self.figure)
        ldos_data=self.plot_ldos(figure=self.figure)
        self.plot_Er_field(figure=self.figure)
        
        
        
        return q_data,flux_data,ldos_data
            
                                                  
    def get_far_field(self,time_after_sources=150,npts=100,ff_angle=math.pi*(5.3/18)):
        
        if self._sim is not None:
            self.time_after_sources=time_after_sources
        
            self._sim.run(until_after_sources=self.time_after_sources)
        
            self.dis=1000/self.fcen_near  #1000 wavelength from the source, distance in z-direction
            self.npts=npts
            self.ff_angle=ff_angle
            self.full_angle=math.pi*(8.9/18)   #only collect up to 89 degree because of the the position of data points are based on collecting angles and vertical distance. I am unable to collect the 90 degree point. 
            self.col_npts=math.floor(self.npts*self.ff_angle/self.full_angle) #npts of collection angle
            self.ff_E=[]
            self.ff_H=[]
            self.ff_r=[]
            self.ff_A=[] # in degrees
        
            #get far field of up-half sphere, notice that here I collect points from a line in r-direction in far-field. The distance between two points isn't the same but their collecting angles are equally spaced. In this way, I can collect more data points at the centre where field concentrate. 
            for n in range(0,npts,1):
                far_field_z2=self._sim.get_farfield(self.near_field_z2,mp.Vector3(math.tan(self.full_angle*(n/(self.npts-1)))*self.dis,0,self.dis))
                self.ff_E.append([far_field_z2[0],far_field_z2[1],far_field_z2[2]])
                self.ff_H.append([far_field_z2[3],far_field_z2[4],far_field_z2[5]])
                self.ff_r.append(math.tan(self.full_angle*(n/(self.npts-1)))*self.dis)
                self.ff_A.append(math.degrees(self.full_angle*(n/(self.npts-1))))
               
        else:
            raise Exception('Need defining simulation first')
               
    def plot_far_field(self,figure=True):
        #construct Pz distributions
        Er=[]
        Ep=[]
        Ez=[]
        Hr=[]
        Hp=[]
        Hz=[]
        for i in range(len(self.ff_E)):
            Er.append(self.ff_E[i][0])
            Ep.append(self.ff_E[i][1])
            Ez.append(self.ff_E[i][2])
        
            Hr.append(self.ff_H[i][0])
            Hp.append(self.ff_H[i][1])
            Hz.append(self.ff_H[i][2])

        R=np.array(self.ff_r)
        A=np.array(self.ff_A)
            
        Er=np.array(Er)  
        Ep=np.array(Ep)    
        Ez=np.array(Ez)  

        Hr=np.array(Hr)  
        Hp=np.array(Hp)    
        Hz=np.array(Hz)

        Er=np.conj(Er)
        Ep=np.conj(Ep)
        Ez=np.conj(Ez)

        Pz=np.real(np.multiply(Er,Hp)-np.multiply(Ep,Hr))
            
        R_col=[] #r position of collected points
        A_col=[] #collected points in angle
        Pz_col=[]
        for i in range(0,self.col_npts,1):
            R_col.append(R[i])
            A_col.append(A[i])
            Pz_col.append(Pz[i])
        
        Pztot=sum(Pz)
        Pztot_col=sum(Pz_col)
        
        #For calculating the PCE at each collection angle
        col_rate_A=[]
        for i in range(len(A)):
            col_rate_A.append(sum(Pz[0:i+1])/Pztot)
        
        
        #PCE of the collection angle set previously
        col_rate=Pztot_col/Pztot
            
            
        if figure is True:
            
            
            plt.figure(dpi=150)
            plt.plot(A, col_rate_A, 'r-', label='Collection rate')
            plt.legend(loc='upper right')
            plt.grid(True)
            plt.xlabel('Collection Angle (degree)')
            plt.ylabel('Collection Efficiency')
            
            thetas = np.radians(np.arange(0, 360, 0.1))
            zeniths = A
            zeniths_col = A_col

            values=[]
            values_col=[]
            
            for i in range(len(thetas)):
                values.append(Pz)
    
            values=np.array(values)
        
            for i in range(len(thetas)):
                values_col.append(Pz_col)
    
            values_col=np.array(values_col)
            
            r, theta = np.meshgrid(zeniths, thetas)
            r2, theta2 = np.meshgrid(zeniths_col, thetas)
            
            fig, ax = plt.subplots(subplot_kw=dict(projection='polar'),dpi=150)
            cs=ax.pcolormesh(theta, r, values,cmap=cm.RdYlBu_r,shading='auto')
            fig.colorbar(cs)
            plt.grid(True)
            plt.title('Full upper half sphere')
            plt.show()
            
            fig, ax2 = plt.subplots(subplot_kw=dict(projection='polar'),dpi=150)
            cs2=ax2.pcolormesh(theta2, r2, values_col,cmap=cm.RdYlBu_r,shading='auto')
            fig.colorbar(cs2)
            plt.grid(True)
            plt.title('Collection rate %1.3f' %(col_rate))
            plt.show()
            
            
        return(col_rate)
    
    